export class MonthlyExpense{
    ID!: number;
    Message!: string;
    UserName!: string;
    Month!: number;
    TotalCredit!: number;
    TotalDebit!: number;
    TotalBalence!: number;
}
