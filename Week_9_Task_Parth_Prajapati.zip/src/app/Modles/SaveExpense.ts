export class SaveExpense{
    code!: number;
    Message!: string;
}