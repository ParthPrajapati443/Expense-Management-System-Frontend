export class GetExpense{
    ID!: number;
    Message!: string;
    ExpenseID!: number;
    ExpenseEmail!: string;
    ExpenseType!: string;
    ExpenseAmount!: number;
    TotalBalence!: string;
    ExpenseReason!: string;
    ExpenseDate!: string;
}